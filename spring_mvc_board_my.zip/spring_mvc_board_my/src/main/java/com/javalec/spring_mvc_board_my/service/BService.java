package com.javalec.spring_mvc_board_my.service;

import org.springframework.ui.Model;

public interface BService {
	public void execute(Model model);
}
